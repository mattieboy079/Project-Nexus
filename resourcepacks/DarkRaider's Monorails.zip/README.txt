######################################################
#         Disney Monorails Pack by DarkRaider        #
######################################################

You are allowed to modify these files for personal use.
Unauthorized reproduction or redistribution of these assets in whole or in part is prohibited.


Important: Beamway Track requires Immersive Railroading version 1.6.0 or above.
	
For best results, use these Immersive Railroading config options:
	damage:requireSolidBlocks - false
	balance:trackFloatingPercent - 100

TO PLACE BEAM:
	Elevate the tracks by at least 1 block from ground using a fence post or wall.


The Walt Disney World Monorail design is a property of WED Engineering/Bombardier.
Walt Disney and Disney are trademarks of the Walt Disney Company.

For inquiries contact:
Discord: DarkRaider#4347