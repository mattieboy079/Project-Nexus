INSTALLATION

You will need:
- Immersive Railroading 		https://www.curseforge.com/minecraft/mc-mods/immersive-railroading
- TrackAPI 				https://www.curseforge.com/minecraft/mc-mods/track-api
- Immersive Engineering (optional)	https://www.curseforge.com/minecraft/mc-mods/immersive-engineering

[1] Make sure you have Immersive Railroading and all dependencies installed
[2] Copy this ZIP folder into your Minecraft resourcepack directory
[3] Start the game and activate the Voxel Trains resource pack


If you're having rendering problems on 1.12.2 (trains disappearing when looked at from certain angles)
try using Optifine HD U E3 https://optifine.net/adloadx?f=OptiFine_1.12.2_HD_U_E3.jar&x=b421

Visit us on Discord: https://discord.gg/aVvtM6C


LICENSE

Copyright (c) 2020 Voxel Trains
All rights reserved